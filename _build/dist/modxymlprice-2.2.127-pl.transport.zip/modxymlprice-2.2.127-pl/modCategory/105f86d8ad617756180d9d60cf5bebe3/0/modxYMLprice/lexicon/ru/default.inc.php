<?php
$_lang['setting_modxYMLprice_offers_key_mapping'] = 'Сопоставление ключей TV или опций msProduct';
$_lang['setting_modxYMLprice_offers_key_mapping_desc'] = 'Генератор настроек: <a target="_blank" href="?a=index&namespace=modxYMLprice&panel=main">тут</a>';

$_lang['setting_modxYMLprice_shop_catalog_id']="ID родительского каталога";
$_lang['setting_modxYMLprice_shop_catalog_id_desc']="Корневая дерриктория каталога isfolder";

$_lang['setting_modxYMLprice_shop_company']="Название вашей компании";
$_lang['setting_modxYMLprice_shop_company_desc']="Tne Best inc.";

$_lang['setting_modxYMLprice_shop_currencyId']="Валюта";
$_lang['setting_modxYMLprice_shop_currencyId_desc']="RUR,USD";

$_lang['setting_modxYMLprice_shop_name']="Название вашего магазина";
$_lang['setting_modxYMLprice_shop_name_desc']="";

$_lang['setting_modxYMLprice_shop_platform']="Название системы управления контентом";
$_lang['setting_modxYMLprice_shop_platform_desc']="";

$_lang['setting_modxYMLprice_shop_url']="Адрес сайта магазина, записанный согласно стандарту RFC 3986";
$_lang['setting_modxYMLprice_shop_url_desc']="<url>http://best.seller.ru</url>";

$_lang['setting_modxYMLprice_snippet_handler']="Сниппет обработчик";
$_lang['setting_modxYMLprice_snippet_handler_desc']="По умолчанию pdoResources";