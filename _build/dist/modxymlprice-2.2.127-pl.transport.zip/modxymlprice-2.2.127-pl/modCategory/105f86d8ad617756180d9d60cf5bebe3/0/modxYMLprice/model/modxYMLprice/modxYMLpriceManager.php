<?php

class modxYMLpriceManager
{
    /* @var modX $modx */
    public $modx;
    public $config = array();
}